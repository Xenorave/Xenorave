"""CCParser test suite."""
