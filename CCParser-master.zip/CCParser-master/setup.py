"""
Legacy setup.py for backwards compatibility.

Note: This project uses pyproject.toml for configuration.
This file is kept for compatibility with older build tools.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
